class BadZippyFile
end
